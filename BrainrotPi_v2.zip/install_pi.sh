#!/bin/bash
echo "[+] Updating system..."
sudo apt update && sudo apt upgrade -y
sudo apt install -y python3-pip ffmpeg imagemagick git
echo "[+] Installing Python packages..."
pip3 install -r requirements.txt
echo "[+] Setup complete. You can now run main_pi.py"
