import time
from main import generate_story, generate_tts, make_video
from upload_youtube import authenticate_youtube, upload_video

def cycle_upload():
    youtube = authenticate_youtube()
    while True:
        print("\n🚀 Neue Runde beginnt …")
        story = generate_story()
        audio_path = generate_tts(story)
        make_video(story, audio_path)
        upload_video(youtube, "final_video.mp4", title=story.split("\n")[0][:100])
        print("🕓 Warte 30 Minuten …")
        time.sleep(10 * 60)

if __name__ == "__main__":
    cycle_upload()