import subprocess

# Trage hier deinen Pfad zur neuen FFmpeg-Version ein:
ffmpeg_path = "C:/ffmpeg/bin/ffmpeg.exe"

def check_amf_support(ffmpeg_path):
    try:
        result = subprocess.run(
            [ffmpeg_path, "-encoders"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            check=True
        )
        output = result.stdout
        print("✅ FFmpeg gefunden: ", ffmpeg_path)
        print("🔍 Suche nach AMF-Encodern...\n")

        found = False
        for line in output.splitlines():
            if "amf" in line.lower():
                print(line)
                found = True

        if not found:
            print("❌ Kein AMF-Support gefunden.")
    except Exception as e:
        print("⚠️ Fehler beim Ausführen von FFmpeg:", e)

check_amf_support(ffmpeg_path)
