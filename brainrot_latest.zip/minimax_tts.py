import torch
from dia.models import TTS

def generate_tts_minimax(text, output_path="minimax_output.wav", device="cuda"):
    print("🧠 Lade Minimax-Modell …")
    try:
        model = TTS.load("nari-tts/diatts:v0.3.0", device=device)
        audio = model.generate(text, sample_rate=24000)
        audio.save(output_path)
        print(f"✅ Minimax TTS abgeschlossen. Gespeichert unter: {output_path}")
        return output_path
    except Exception as e:
        print("❌ Fehler bei Minimax TTS:", e)
        return None
