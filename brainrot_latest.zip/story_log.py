import json
import hashlib
import os

USED_STORY_LOG = "used_stories.json"

def story_already_used(story_text):
    h = hashlib.sha256(story_text.encode("utf-8")).hexdigest()
    if os.path.exists(USED_STORY_LOG):
        with open(USED_STORY_LOG, "r", encoding="utf-8") as f:
            used = json.load(f)
    else:
        used = []
    return h in used

def log_used_story(story_text):
    h = hashlib.sha256(story_text.encode("utf-8")).hexdigest()
    if os.path.exists(USED_STORY_LOG):
        with open(USED_STORY_LOG, "r", encoding="utf-8") as f:
            used = json.load(f)
    else:
        used = []
    if h not in used:
        used.append(h)
        with open(USED_STORY_LOG, "w", encoding="utf-8") as f:
            json.dump(used, f)
