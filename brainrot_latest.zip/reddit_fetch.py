import os
import praw
from dotenv import load_dotenv

load_dotenv()

REDDIT_CLIENT_ID = os.getenv("REDDIT_CLIENT_ID")
REDDIT_CLIENT_SECRET = os.getenv("REDDIT_CLIENT_SECRET")
USER_AGENT = "ShortsStoryFetcher/0.1 by EmilAI"

reddit = praw.Reddit(
    client_id=REDDIT_CLIENT_ID,
    client_secret=REDDIT_CLIENT_SECRET,
    user_agent=USER_AGENT
)

subreddits = ["Story", "nosleep", "LetsNotMeet"]

def fetch_reddit_story():
    for sub in subreddits:
        print(f"🔎 Suche in r/{sub}...")
        submissions = reddit.subreddit(sub).top(time_filter="day", limit=10)
        for submission in submissions:
            if len(submission.selftext) > 200 and not submission.stickied:
                title = submission.title.strip()
                body = submission.selftext.strip().replace("\n", " ")
                story = f"{title}. {body}"
                print(f"✅ Story gefunden: {title}")
                return {
                    "title": title,
                    "text": body,
                    "combined": story,
                    "subreddit": sub,
                    "url": submission.url
                }
    print("⚠️ Keine geeignete Story gefunden.")
    return None

if __name__ == "__main__":
    story = fetch_reddit_story()
    if story:
        print("\n--- STORY ---\n")
        print(story["combined"])
